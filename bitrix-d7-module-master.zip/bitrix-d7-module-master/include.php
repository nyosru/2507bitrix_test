<?php
Bitrix\Main\Loader::registerAutoloadClasses(
	"brainkit.d7",
	array(
		"Brainkit\\D7\\Test" => "lib/test.php",
	)
);
