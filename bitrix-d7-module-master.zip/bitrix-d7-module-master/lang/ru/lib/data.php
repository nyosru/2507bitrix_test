<?
$MESS["DATA_ENTITY_ID_FIELD"] = "ID";
$MESS["DATA_ENTITY_TITLE_FIELD"] = "Заголовок";
$MESS["DATA_ENTITY_SORT_FIELD"] = "Сортировка";
$MESS["DATA_ENTITY_CREATED_FIELD"] = "Дата создания";